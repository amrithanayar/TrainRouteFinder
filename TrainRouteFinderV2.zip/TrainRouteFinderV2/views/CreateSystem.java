package views;
import views.MainMenuGUI;
/**
 * main class to run the program
 */
import java.io.File;
import java.io.IOException;

import views.MainMenuGUI;
public class CreateSystem {

	/**
	 * this method runs the program
	 * @param args
	 */

	public static void main(String[] args) {
		MainMenuGUI runjava = new MainMenuGUI();
		runjava.CreateMainFrame();

	}

}
